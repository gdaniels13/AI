
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *Greg Daniels
 *gdaniels13@gmail.com
 *A00798340
 */
public class Operators {


    
    
}
